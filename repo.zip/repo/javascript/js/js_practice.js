// Test function for javascript.
function helloJavaScript(){
    document.getElementById("demo"). innerHTML = "Hello, JavaScript!!";
}

// Direct Show on page
// document.write("Hii")

// Window alert
// window.alert("Welcome from JavaScript!!");
// alert("Welcome from JavaScript!!");

// Consol log
console.log("Hello, JavaScript!!");

// If we want print page
function printCurrentPage() {
    window.print();
}

// let and const
// const x = 5;
// const y = 5;
// const sum = x + y;

let x = 5;
let y = 5;
let sum = x + y;

document.getElementById("sum").innerHTML = sum;

// function for change car name onclick event
// Use Try Catch
function changeCarName(){
    try{
        carName = "B.M.W";
        document.getElementById("car").innerHTML = carName;
    }
    catch(err){
        console.log(err);
    }

}

// Demo of Array
const cars = ['Supra','Volvo','Saab'];

cars[2] = "Toyota";  // Change an element
cars.push("B.M.W."); // Add an element
document.getElementById("listArray").innerHTML = cars; // Display the array

// Demo of dictionary
const fruit = {name:"Apple", color:"red"};
console.log("Before changes!!");
console.log(fruit); // print before fruit.

fruit.color = "Green"; // Change a property
fruit.season = "Winter"; // Add a property

console.log('After changes!');
console.log(fruit); // print after fruit.
document.getElementById("dict").innerHTML = "Fruit name is" + " " + fruit.name + " " + "Color is" + " " + fruit.color + " Season is" + " " + fruit.season; // Display the dictionary

// demo od boolean
var a = 10;
var b = 10;
var result = a == b;
console.log(result);

let text = "New";
text += " Line";

document.getElementById("addLine").innerHTML = text;

// Function with parameters

function mulTwoNumber(c,d){
    return c * d;
}
let output = mulTwoNumber(10,10);
console.log(output);

// show date function
function todayDateTime(){
    document.getElementById("date").innerHTML = Date();
}

let text_len = "abhi";
console.log(text_len.length); // show length of text length is not function 

let e = "abhi"; // e is string
let f = new String("abhi"); // f is an object.

console.log(e,f);
console.log(typeof e, typeof f);

// The padEnd() method pads a string from the end.
let pad_ex = "5";
let padaddend = pad_ex.padEnd(4,'0');
console.log(padaddend);

// The padEnd() method pads a string from the end.
let pad_ex_2 = "5";

// console.log((pad_ex_2.toString())); // convert to string.
// let padaddstart = pad_ex_2.padStart(4,'0');

let padaddstart = pad_ex_2.repeat(5); // repeat string .repeat(How many times?)
console.log(padaddstart);

let header = "Template Strings";
let tags = ['Car','Apple','Android'];

let html = `<h2>${header}</h2><ul>`;

for(let i of tags){
    html += `<li>${i}</li>`;
}

html += `</ul>`;
document.getElementById("demo2").innerHTML = html;

let g = 9007199254740992 === 9007199254740993;
let r = 5 + "5";
let t = 5 - "5";

console.log(g)
console.log(r);
console.log(t);

// forloop..
let cd = ['bmw', 'audi', 'supra'];

for(let i of cd){
    console.log(i);
}

let text2 = '<ul>';
for(const element of cd){
    text2 += "<li>" + element +  "</li>";
}
text2 += '</ul>';
document.getElementById("demo3").innerHTML = text2;
document.getElementById("demo4").innerHTML = cd.join(" , ");

// loader

document.onreadystatechange = function () {
    if (document.readyState !== "complete") {
        document.querySelector(
            "body").style.visibility = "hidden";
        document.querySelector(
            "#loader").style.visibility = "visible";
    } else {
        document.querySelector(
            "#loader").style.display = "none";
        document.querySelector(
            "body").style.visibility = "visible";
    }
};

// JQuery

$("#demo5").click( function(){
    alert("Please wait...this is from jquery");
});

// Jquery search filter
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myDiv *").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > 1)
    });
  });
});