from core.views import *
from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [

    # Authentication
    path('login/', LoginView.as_view(template_name='login.html'), name="user-login"),
    path('logout/', LogoutView.as_view(), name="user-logout"),
    path('register/', StudentView.RegisterUser.as_view(), name="user-register"),

    # Student
    path('', StudentView.StudentListView.as_view(), name='student-list'),
    path('create_student/', StudentView.StudentCreateView.as_view(), name="student-create"),
    path('update_student/<uuid:pk>/', StudentView.StudentUpdateView.as_view(), name="student-update"),
    path('delete_student/<uuid:pk>/', StudentView.StudentDeleteView.as_view(), name="student-delete"),

    # Todo
    path('todo/', TodoView.TodoListView.as_view(), name="todo"),
    path('create_todo/', TodoView.CreateTodo.as_view(), name="create_todo"),
    path('delete_todo/<uuid:pk>/', TodoView.DeleteTodo.as_view(), name="delete_todo"),
    path('complete/<uuid:pk>/', TodoView.CompletedTodo.as_view(), name="complete_todo"),

    # Note
    path('note/', NoteView.NoteListView.as_view(), name="note"),
    path('create_note/', NoteView.CreateNoteView.as_view(), name="create_note"),
    path('update_note/<uuid:pk>/', NoteView.UpdateNoteView.as_view(), name="update_note"),
    path('delete_note/<uuid:pk>/', NoteView.DeleteNoteView.as_view(), name="delete_note"),

    path('test_validation/', TestFormView.as_view(), name="test_validation"),
]