from django.contrib.auth.models import User
from django.db import models
import uuid

class BaseModel(models.Model):
    """Base class model."""
    class Meta:
        abstract = True
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Student(BaseModel):
    """Students model."""

    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    enrollment_number = models.CharField(max_length=255, unique=True)
    current_address = models.TextField()
    phone_number = models.CharField(max_length=11, blank=True, null=True)

    def __str__(self):
        return self.first_name

class Todo(BaseModel):
    """Todo model."""

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    todo = models.TextField()
    complete = models.BooleanField(default=False)
    create_date = models.DateField(auto_now_add=True)
    complete_date = models.DateField(auto_now=True)

    def __str__(self) -> str:
        return f"{self.user}, {self.todo}"

    class Meta:
        ordering = ('-created_at',)

class Note(BaseModel):
    """Note model."""

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    head = models.CharField(max_length=255)
    note = models.TextField()

    def __str__(self) -> str:
        return str(self.user)
    
    class Meta:
        ordering = ('-created_at',)