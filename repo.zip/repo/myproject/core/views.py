"""Core view."""

from core.models import *
from datetime import date
from typing import Any, Dict
from django.contrib import messages
from django.urls import reverse_lazy
from django.contrib.auth.models import User
from django.utils.safestring import mark_safe 
from django.forms.models import BaseModelForm
from django.contrib.auth import login as auth_login
from django.contrib.auth.hashers import make_password
from core.forms import NoteForm, TodoForm, StudentForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, CreateView, TemplateView
from django.views.generic.edit import UpdateView, DeleteView, FormView
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse


# STUDENTS...
class StudentView:
    """Handel create, retrieve, update and delete students."""

    class StudentListView(LoginRequiredMixin,ListView):
        """Listing all students."""

        model = Student
        context_object_name = 'student'
        paginate_by = 6
        template_name = 'student_list.html'

        def get_queryset(self):
            search = self.request.GET.get('search', '') 
            student = Student.objects.filter(first_name__icontains=search)
            return student

    class StudentCreateView(LoginRequiredMixin,CreateView):
        """Create student objects."""

        model = Student
        template_name = 'student_list.html'
        fields = ["first_name","last_name","phone_number","enrollment_number","current_address"]
        success_url = reverse_lazy("student-list")

        def form_valid(self, form):
            """ 
            Handle the form validation when creating students.
            
            Args:
                form: The form instance containing the create data.

            Returns:
                Messages we pass.
            """

            user_first_name = form.cleaned_data["first_name"]
            user_last_name = form.cleaned_data["last_name"]
            html_content = f"""Student <strong>"{user_first_name} {user_last_name}"</strong> created successfully!!"""
            message =  mark_safe(html_content)
            messages.success(self.request, message)

            return super().form_valid(form)

    class StudentUpdateView(LoginRequiredMixin,UpdateView):
        """Update student objects."""

        model = Student
        template_name = 'student_list.html'
        fields = ["first_name","last_name","phone_number","enrollment_number","current_address"]
        success_url = reverse_lazy("student-list")

        def form_valid(self, form):
            """ 
            Handle the form validation when updating details.
            
            Args:
                form: The form instance containing the update data.

            Returns:
                Messages we pass.
            """

            user_first_name = form.cleaned_data["first_name"]
            user_last_name = form.cleaned_data["last_name"]
            html_content = f"""Change student <strong>"{user_first_name} {user_last_name}"</strong> details successfully!!"""
            message = mark_safe(html_content)
            messages.success(self.request, message)

            return super().form_valid(form)

    class StudentDeleteView(LoginRequiredMixin,DeleteView):
        """Delete student objects."""

        model = Student
        template_name = 'student_list.html'
        success_url = reverse_lazy("student-list")

        def form_valid(self, form):
            """ 
            Handle the form validation when delete students..
            
            Args:
                form: The form instance containing the delete data.

            Returns:
                Messages we pass.
            """

            messages.success(self.request, "Student deleted successfully!!")
            return super().form_valid(form)

    class RegisterUser(CreateView):
        """Create a new user."""
        model = User
        template_name = "user_register.html"
        fields = ["username", "email", "password"]
        success_url = reverse_lazy('user-login')
        
        def form_valid(self, form):

            form.instance.password = make_password(form.cleaned_data['password'])
            form.save()
            return super().form_valid(form)

# TODOS..
class TodoView:
    """Handle create,retrieve, update and delete todo."""

    class TodoListView(LoginRequiredMixin,ListView):
        """Handle user todo list"""

        model = Todo
        form = TodoForm()
        context_object_name = "todo_list"
        template_name = 'todo.html'


        def get_context_data(self, **kwargs: Any):
            context =  super().get_context_data(**kwargs)

            uncompleted_todo = Todo.objects.filter(user=self.request.user, complete=False)
            completed_todo = Todo.objects.filter(user=self.request.user, complete=True, complete_date=date.today())

            # Custom pagination in completed tasks.

            page_num = self.request.GET.get('page',1)
            paginator = Paginator(completed_todo, 4)

            try:
                page_obj = paginator.page(page_num)
            except PageNotAnInteger:
                page_obj = paginator.page(1)
            except EmptyPage:
                page_obj = paginator.page(paginator.num_pages)

            context['form'] = self.form
            context['uncompleted_todo'] = uncompleted_todo
            context['completed_todo'] = page_obj

            return context

    class CreateTodo(LoginRequiredMixin,CreateView):
        """Create Todo."""
        
        model = Todo
        template_name = 'todo.html'
        fields = ['todo']
        success_url = reverse_lazy('todo')

        def form_valid(self, form):

            form.instance.user = self.request.user
            form.save()
            todo_list = Todo.objects.filter(user=self.request.user, complete=False).values()

            return JsonResponse({'status':'save', 'todo_list': list(todo_list)})
        
    class DeleteTodo(LoginRequiredMixin,DeleteView):
        """Delete Todo."""
        model = Todo
        template_name = "todo.html"
        success_url = reverse_lazy('todo')

    class CompletedTodo(LoginRequiredMixin,UpdateView):
        """Check task completed status."""

        model = Todo
        template_name = 'todo.html'
        fields = ['complete']
        success_url =reverse_lazy('todo')

        def form_valid(self, form):

            form.instance.complete = True
            form.save()
            today = date.today()
            todo_complete_list = Todo.objects.filter(user=self.request.user,complete=True,complete_date=today).values()
            return JsonResponse({'status': 'update','todo_complete_list':list(todo_complete_list)})

# NOTES..
class NoteView:
    """Handle create,retrieve, update and delete note."""

    class NoteListView(LoginRequiredMixin,ListView):
        """Listing all note of user."""
        model = Note
        form = NoteForm()
        template_name = 'note.html'
        
        def get_context_data(self, **kwargs: Any):
            context = super().get_context_data(**kwargs)
            
            context['form'] = self.form
            context['notes'] = Note.objects.all()

            return context

    class CreateNoteView(LoginRequiredMixin,CreateView):
        """Create note for user."""
        model = Note
        template_name = 'note.html'
        fields = ['head', 'note']
        success_url = reverse_lazy('note')
    
        def form_valid(self, form):
            form.instance.user = self.request.user
            form.save()

            return super().form_valid(form)
    
    class UpdateNoteView(LoginRequiredMixin,UpdateView):
        """Update note for user."""
        model = Note
        template_name = "note.html"
        fields = ['head', 'note']
        success_url = reverse_lazy('note')
    
    class DeleteNoteView(LoginRequiredMixin,DeleteView):
        """Delete note for user."""
        model = Note
        template_name = 'note.html'
        success_url = reverse_lazy('note')


# VALIDATION OF DJANGO FORM..
class TestFormView(CreateView):
    """Test validation in form."""
    model = Student
    form_class = StudentForm
    template_name = 'form_validations.html'
    success_url = reverse_lazy('student-list')

    def get_context_data(self, **kwargs: Any):
        context = super().get_context_data(**kwargs)
        
        context['form'] = self.form_class(self.request.POST)
        return context
    
    def form_invalid(self, form: BaseModelForm) -> HttpResponse:
        print("==>",form.errors)
        return super().form_invalid(form)
  