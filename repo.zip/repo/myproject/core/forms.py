from typing import Any
from django import forms
from core.models import Note, Todo, Student
from django.utils.translation import gettext_lazy as _


class TodoForm(forms.ModelForm):
    class Meta:
        model = Todo
        fields = ['todo']

class NoteForm(forms.Form):
    """Form for note"""
    head = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    note = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
        
class StudentForm(forms.ModelForm):

    class Meta:
        model = Student
        fields = ['first_name','last_name','enrollment_number','current_address','phone_number']

        widgets ={
            'first_name': forms.TextInput(attrs={
                'class': "form-control",
                'placeholder': 'first name',
                }),

            'last_name': forms.TextInput(attrs={
                'class': "form-control",
                'placeholder': 'Last Name'
                }),

            'enrollment_number': forms.NumberInput(attrs={
                'class': "form-control",
                'placeholder': 'enrollment number'
                }),

            'current_address': forms.Textarea(attrs={
                'class': "form-control",
                'placeholder': 'current address'
                }),

            'phone_number': forms.NumberInput(attrs={
                'class': "form-control",
                'placeholder': 'phone number'
                }),
        }
    
    def clean(self):

        cleaned_data = super().clean()

        first_name = cleaned_data.get('first_name')
        last_name = cleaned_data.get('last_name')

        if first_name and last_name and first_name.lower() == last_name.lower():
            print("Please enter different first and last names")
            raise forms.ValidationError("Name not be same")

    def clean_current_address(self):
        current_address = self.cleaned_data.get('current_address')

        # print(current_address)

        if len(current_address) <= 10:
            raise forms.ValidationError("Address must be more than 10 char.")
        
        return current_address
    
    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')

        print(phone_number)

        if phone_number:
            if len(phone_number) != 10:
                raise forms.ValidationError("Enter valid phone number")
            return phone_number