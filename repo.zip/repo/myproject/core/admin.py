from django.contrib import admin
from core.models import Student,Todo, Note
# Register your models here.

admin.site.register(Student)
admin.site.register(Todo)
admin.site.register(Note)