class Parent():
    """Defining parent class."""

    def __init__(self):
        self.value = "parent class!!"
    
    def show(self):
        print(self.value)

class Child(Parent):
    """
    Defining child class when child class can inherit attributes and methods from parent class.
    
    args:
        Parent: Inherit parent class,

    """

    def __init__(self):
        self.value = "child class!!"
    
    def show(self):
        print(self.value)


# Create an objects
parent_class_object = Parent()
child_class_object = Child()

parent_class_object.show()
child_class_object.show()