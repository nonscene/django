def method_overload(a):
    """
    Create example of method overloading.
    
    args:
        a: accept attributes
    """
    return a

print(method_overload(1))
print(method_overload(1.00))
print(method_overload([1,2,3]))
print(method_overload("test_string"))