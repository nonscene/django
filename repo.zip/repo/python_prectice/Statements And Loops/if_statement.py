"""
Simple programs for if statements.
"""

# marks = int(input("Enter your marks: "))

# if marks < 30:
#     print("Failed!!")
# elif marks > 75:
#     print("Passed with distinction!!")
# else:
#     print("Passed!!")


discount = 0
amount = 5500

if amount > 10000:
    discount = amount * 20 / 100

elif amount > 5000:
    discount = amount * 10 / 100

elif amount > 1000:
    discount = amount * 5 / 100

total = amount - discount

print(f"Amount:          ${amount}")
print(f"Discount amount:-${discount}")
print(f"Total amount:    ${total}")