"""
A example of forloop
"""
# 1................................................................
mystr = "All animals are equal. Some are more equal"
vowels = "aeiou"
count = 0

for i in mystr:
    if i.lower() in vowels: count += 1
print("Number of vowels: {}".format(count))

# 2................................................................
digits = [str(i) for i in range(11)]
print(digits)
mystr = "Hello001, Pyth0on45"
char = []

for i in mystr:
    if i not in digits:
        char.append(i)

newstr = ''.join(char)
print(newstr)

list2 = [1,2,3,4,5]
# list2[2] = 10
# print(list2)

# list = ["a", "c", "e"]
# list[1] = "b"
# print(list)

# for i in list2:
#     print(i, end=" ")

# n = 5
# for i in range(1,n):
#     print(" *")
#     for j in range(1, i+1):
#         print(" *", end=" ")