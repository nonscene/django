"""
Simple program for while loop.
"""

count = 0

while count < 5:
    count += 1
    print("count {}".format(count))

print("End of while loop!!")


number = '0'
while number.isnumeric() == True:
    
    if number.isnumeric() == True:
        number = input('Enter a number: ')
        print("Entered number: {}".format(number))

print("Please enter a number instead of '{}'".format(number))