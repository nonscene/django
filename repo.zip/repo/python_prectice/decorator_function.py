def hello_decorator(func):
    def inner1(*args, **kwargs):

        print("Before Execution!!")
        
        returned_value = func(*args, **kwargs)
        
        print("After Execution!!")
        return returned_value
    return inner1

@hello_decorator
def sum_two_numbers(a,b):
    print("inside the function")
    return a + b
print("Sum =", sum_two_numbers(1,2))


def decor1(func):
    def inner():
        print("inside the inner() function")
        x = func()
        return x * x
    return inner

def decor2(func):
    def inner():
        print("##############")
        x,y = func()
        return x+y
    return inner

@decor2
def num():
    print("num() called!!")
    return 50,20
print(num())