"""
Examples of inheritance
"""

class SingleInheritance:
    """example of single inheritance."""

    class Parent:
        """"Create base parent class."""

        def func1(self):
            print("Function in parent class.")


    class Child(Parent):
        """Inherit parent class for child class."""

        def func2(self):
            print("Function in child class.")

single_inheritance_object = SingleInheritance.Child()
single_inheritance_object.func1()
single_inheritance_object.func2()


class MultipleInheritance:
    """example of multiple inheritance."""

    class Mother:
        """Create parent class."""
        mother_name = ""
        
        def mother(self):
             print(self.mother_name)
    
    class Father:
        """Create parent class."""
        father_name = ""

        def father(self):
            print(self.father_name)  
    
    class Son(Mother, Father):
        """Inherit two parent classes for child class."""

        def parent(self):
            print("Father :", self.father_name)
            print("Mother :", self.mother_name)

multiple_inheritance_object = MultipleInheritance.Son()
multiple_inheritance_object.father_name = "Alex"
multiple_inheritance_object.mother_name = "Alice"
multiple_inheritance_object.parent()


class MultilevelInheritance:
    """example of multilevel inheritance."""

    class Grandfather:
        """Base class."""

        def __init__(self, grand_father_name):
            self.grand_father_name = grand_father_name

    class Father(Grandfather):
        """
        Intermediate class.
        Inherit Base class.
        """
        
        def __init__(self, father_name, grand_father_name):
            self.father_name = father_name
            self.grand_father_name = grand_father_name

            MultilevelInheritance.Grandfather(self.grand_father_name)
    
    class Son(Father):
        """
        Derived class.
        Inherit Intermediate class.
        """

        def __init__(self, son_name, father_name, grand_father_name):
            self.son_name = son_name

            MultilevelInheritance.Father(father_name, grand_father_name)
        
        def show_name(self):
            print("Grandfather: ", self.grand_father_name)
            print("Father: ", self.father_name)
            print("Son: ", self.son_name)

multilevel_inheritance_objects = MultilevelInheritance.Son("Alice","Alex","Rio")
multilevel_inheritance_objects.show_name()


class HierarchicalInheritance:
    """Example of hierarchical inheritance."""

    class Parent:
        """Base parent class."""

        def func1(self):
            print("Parent class called!!")
    
    class ChildOne(Parent):
        """Derived child class.Inherit by parent class."""

        def func2(self):
            print("First Child class called!!")
    
    class ChildTwo(Parent):
        """Derived child class.Inherit by parent class."""

        def func3(self):
            print("Second Child class called!!")

hierarchical_inheritance_object = HierarchicalInheritance.ChildOne()
hierarchical_inheritance_object_2 =  HierarchicalInheritance.ChildTwo()
hierarchical_inheritance_object.func2()
hierarchical_inheritance_object_2.func3()


class HybridInheritance:
    """Example of hybrid inheritance."""

    class School:
        """Define a class."""

        def func1(self):
            print("Function in school called!!")
    
    class Student(School):
        """Inherit by school class."""

        def func2(self):
            print("Function inside student called!!")
    
    class Staff(School):
        """Inherit by school class."""

        def func3(self):
            print("Function inside staff called!!")
    
    class Teacher(Student, Staff):
        """Inherit by two classes."""

        def func4(self):
            print("Function inside teacher called!!")

hybrid_inheritance_object_teacher = HybridInheritance.Teacher()
hybrid_inheritance_object_teacher.func3()
hybrid_inheritance_object_student = HybridInheritance.Student()
hybrid_inheritance_object_student.func1()