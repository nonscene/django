print(len("Abhi"))

print(len([1,2,3]))