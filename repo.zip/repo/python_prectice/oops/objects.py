class Employee():
    """Base employee class."""

    def __init__(self,name):
        self.name = name

    def employee_name(self):
        return print(self.name)

obj = Employee("Abhi")
obj.employee_name()