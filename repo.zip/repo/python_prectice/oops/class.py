class Base:
    """Base class."""

    def base_function(self):
        return print("Base function")

Base.base_function()
