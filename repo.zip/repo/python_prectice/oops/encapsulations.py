class Person:
    """"Define base class."""

    def __init__(self,name):
        self.name = name
    
    def show(self):
        return print(self.name)

person1 = Person("Alice Name")
person1.show()