from datetime import date   # Data abstraction.

class Person:
    """Define base person class."""

    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    # Class method to create a person objects by birth year.
    @classmethod
    def fromBirthYear(cls, name, year):
        return cls(name, date.today().year - year)
    
    @staticmethod
    def isAdult(age):
        return age > 18


person1 = Person("Abhi", 21) 
person1_age = person1.age
person1_name = person1.name
print(person1.isAdult(person1_age))

person2 = Person.fromBirthYear("Alice", 2003)
print("Person Name: {}".format(person2.name))
print(f"Person Age: {person2.age}")
print(person2.isAdult(person2.age))