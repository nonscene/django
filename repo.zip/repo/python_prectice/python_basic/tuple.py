tuple = ()
print(type(tuple))

tuple = ('abc',123,1.2)

print(tuple) # Print complete tuple.

print(tuple[0]) # Print tuple by index.

print(tuple[1:3]) # Print tuple by slice.
print(tuple[::-1])
print(tuple[0:])

for i in tuple:
    print(type(i))