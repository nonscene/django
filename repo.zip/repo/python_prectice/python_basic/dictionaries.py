dict = {}
print(type(dict))

dict['one'] = 1
dict[2] = 'Two'

print(dict) # print the dictionary.

print(dict['one']) # print the dictionary by key.

print(dict.keys()) # print all the keys in the dictionary.

print(dict.values()) # print all the values in the dictionary.

dict[2] = 2 # change value by key.

print(dict)