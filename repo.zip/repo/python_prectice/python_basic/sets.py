sets = set()
print(type(sets))

sets = {123, 'stings', 20.22, 1+2j}
print(sets)
