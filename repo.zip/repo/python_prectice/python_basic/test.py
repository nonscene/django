# print("Hello world!")

# integer_value = 100                 # An integer value
# float_value = 100.00                # A float value
# string_value = 'This is a string'   # A string value

# print(integer_value, type(integer_value))
# print(float_value, type(float_value))
# print(string_value, type(string_value))

# del integer_value


a = True # boolean value
b = 10.5

"""
In this case when boolean value is true then they contain 1 and
false then they contain 0 
"""
c = a + b
print(c)

