list = ['abc', 123, 1.2]
list2 = ['def', 456]

print(list[0]) # Print elements by index.

print(list[1:2]) # Print elements by slice.

print(list + list2) # Print concatenated list.

print(list * 2) # Print lists two times.

# Print datatypes of elements of list.
for i in list:
    print(type(i))